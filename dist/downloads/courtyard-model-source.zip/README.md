# Editable Courtyard House model

Run `npm ci`, then `npm run model`. The result is written to `dist/assets/courtyard-house.glb`. Edit `model-source/courtyard-house.mjs` to change the model. This ZIP contains the model generator only; get the complete project ZIP for the website and viewer.

Image-based architectural concept. Visible reference annotations 30 m × 12 m conflict with image proportions; internal dimensions, 190 mm wall thickness and 2.8 m wall height are assumptions. No construction accuracy is claimed.
